<form method="post" action="../u-php/s-registration.php" >
		<table align="center" style="font-weight: bold; font-size: 20px;">
			<tr class="form-group has-success">
				<td><input required="required" class="form-control" id="inputSuccess" type="text" name="staff_id" placeholder="Staff ID" size="40" ></td>
				<td><input required="required" class="form-control" id="inputSuccess" type="text" name="fname" placeholder="First Name" size="40" ></td>
			</tr>
			<tr class="form-group has-success">
				<td><input required="required" class="form-control" id="inputSuccess" type="text" name="lname" placeholder="Last Name" size="40" ></td>
				<td><input required="required" class="form-control" id="inputSuccess" type="text" name="contact" placeholder="Contact" size="40" ></td>
			</tr>
			<tr class="form-group has-success">
				<td><input required="required" class="form-control" id="inputSuccess" type="text" name="email" placeholder="Email" size="40" ></td>
				<td><input required="required" class="form-control" id="inputSuccess" type="text" name="address" placeholder="Address" size="40" ></td>
			</tr>
			<tr class="form-group has-success">
				<td><input required="required" class="form-control" id="inputSuccess" type="text" name="department" placeholder="Department" size="40" ></td>
				<td><input class="btn btn-info btn-sm" type="submit" name="staff" value="Update staff" ></td>
			</tr>
		</table>
	</form>
<form method="post" action="../u-php/su-registration.php" >
		<table align="center" style="font-weight: bold; font-size: 20px;">
			<tr class="form-group has-success">
				<td><input required="required" class="form-control" id="inputSuccess" type="text" name="item_id" placeholder="Item ID" size="40" ></td>
				<td><input required="required" class="form-control" id="inputSuccess" type="text" name="item_name" placeholder="Item Name" size="40" ></td>
			</tr>
			<tr class="form-group has-success">
				<td><input required="required" class="form-control" id="inputSuccess" type="text" name="quantity" placeholder="Quantity" size="40" ></td>
				<td><input required="required" class="form-control" id="inputSuccess" type="text" name="manf_date" placeholder="Manufacture date" size="40" ></td>
			</tr>
			<tr class="form-group has-success">
				<td><input required="required" class="form-control" id="inputSuccess" type="text" name="expire_date" placeholder="Expire Date" size="40" ></td>
				<td><input required="required" class="form-control" id="inputSuccess" type="text" name="supplier" placeholder="Supplier" size="40" ></td>
			</tr>
			<tr class="form-group has-success">
				<td><input required="required" class="form-control" id="inputSuccess" type="text" name="country" placeholder="Country" size="40" ></td>
				<td><input class="btn btn-info btn-sm" type="submit" name="item" value="Update Item" ></td>
			</tr>
		</table>
	</form>
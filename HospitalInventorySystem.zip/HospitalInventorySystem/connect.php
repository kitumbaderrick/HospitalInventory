<?php
	$host='localhost';
	$user='root';
	$pass='';
	$db='inventory';

	// Create connection
$con = new mysqli($host, $user, $pass, $db);
// Check connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}
?>
<form method="post" action="../d-php/su-registration.php" >
		<table align="center" style="font-weight: bold; font-size: 20px;">
			<tr class="form-group has-success">
				<td><input required="required" class="form-control" id="inputSuccess" type="text" name="item_id" placeholder="Enter Item ID" size="40" ></td>
				<td><input class="btn btn-info btn-sm" type="submit" name="delete" value="Remove Item" ></td>
			</tr>
		</table>
	</form>
# Hospital-Inventory-System
A hospital inventory system designed using PHP, HTML5, CSS, JavaScript, SQL
The system has got seven view/ categories of user including;
Admin (with only one account)
Doctor (1 - Many accounts)
Nurse (1 - Many accounts)
Accountant (1 - Many accounts)
Recieptionist (1 - Many accounts)
Labaratorist (1 - Many accounts)
Pharmacist (1 - Many accounts)

*NOTE*;
The system has missing modules and is still under development.
The system is designed for Kyambogo University medical Center located in Uganda, Kampala District.
